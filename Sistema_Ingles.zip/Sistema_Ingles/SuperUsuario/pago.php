<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estado de Pago</title>
    <style>
        /* Barra lateral */
        
    

        /* Contenido principal */
       
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-bottom: 30px;
        }

        input[type="text"], input[type="number"] {
            padding: 10px;
            font-size: 16px;
            width: 100%;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button {
            padding: 12px 20px;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            background-color: #0056b3;
        }

       
        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        .pagado {
            color: green;
            font-weight: bold;
        }

        .pendiente {
            color: red;
            font-weight: bold;
        }

        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            height: 100vh;
            background-color: #f4f4f4;
        }

        .main-content {
            margin-left: 270px;
            padding: 20px;
            width: 100%;
            box-sizing: border-box;
        }

        .container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            padding: 30px;
            max-width: 800px;
            margin: 0 auto;
        }

        h1 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ccc;
        }
        
        th {
            background-color: #007bff;
            color: white;
        }

        .aprobado { color: green; font-weight: bold; }
        .reprobado { color: red; font-weight: bold; }

        .search-form {
            text-align: center;
            margin-bottom: 20px;
        }

        .search-form select, .search-form button {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 250px;
        }

        .search-form button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }

        .search-form button:hover {
            background-color: #0056b3;
        }
        .sidebar a:hover {
            background-color: #0056b3;
        }

        .dropdown {
            position: relative;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #007bff;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
            width: 200px;
            border-radius: 5px;
            left: 100%;
            top: 0;
        }

        .dropdown:hover > .dropdown-content {
            display: block;
        }

        .dropdown-content a {
            padding: 10px;
            display: block;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .dropdown-content a:hover {
            background-color: #0056b3;
        }

        .search-form {
            text-align: center;
            margin-bottom: 20px;
        }

        .search-form input {
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 250px;
        }

        .search-form button {
            padding: 8px 15px;
            font-size: 16px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .search-form button:hover {
            background-color: #0056b3;
        } .sidebar {
            background-color: #007bff;
            color: white;
            width: 250px;
            padding: 20px;
            height: 100%;
            box-sizing: border-box;
            position: fixed;
        }

        .sidebar h2 {
            color: white;
            font-size: 24px;
            margin-bottom: 30px;
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            display: block;
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
        }

        .sidebar a:hover {
            background-color: #0056b3;
        }

    </style>
</head>
<body>

<!-- Barra lateral -->
<div class="sidebar">
    <h2>Menú</h2>
    <a href="index.html">Inicio</a>
    <a href="registro.php">Registro</a>
    <a href="ver_calificaciones.php">Ver Calificaciones</a>
    <a href="pago.php">Pagos</a>
    
<div class="dropdown">
        <a href="#">Unidad Académica</a>
        <div class="dropdown-content">
            <div class="dropdown">
                <a href="#">Chicontepec</a>
                <div class="dropdown-content">
                    <a href="asignar_calificaciones.php?unidad=Chicontepec">Asignar Calificaciones</a>
                    <a href="ver_alumnos.php?unidad=Chicontepec">Ver alumnos</a>

                </div>
            </div>
            <div class="dropdown">
                <a href="#">Benito Juárez</a>
                <div class="dropdown-content">
                    <a href="asignar_calificaciones.php?unidad=BenitoJuarez">Asignar Calificaciones</a>
                    <a href="ver_alumnos.php?unidad=BenitoJuarez">Ver alumnos</a>

                </div>
            </div>
            <div class="dropdown">
                <a href="#">Huayacocotla</a>
                <div class="dropdown-content">
                    <a href="asignar_calificaciones.php?unidad=Huayacocotla">Asignar Calificaciones</a>
                    <a href="ver_alumnos.php?unidad=Huayacocotla">Ver alumnos</a>

                </div>
            </div>
            <div class="dropdown">
                <a href="#">Tlacolula</a>
                <div class="dropdown-content">
                    <a href="asignar_calificaciones.php?unidad=Tlacolula">Asignar Calificaciones</a>
                    <a href="ver_alumnos.php?unidad=Tlacolula">Ver alumnos</a>
                </div>
                
            </div>
        </div>
    </div>
</div>


<div class="main-content">
    <div class="container">
        <h1>Estado de Pago del Alumno</h1>

        <!-- Formulario para seleccionar número de control -->
        <form id="buscar-form" action="" method="POST">
            <label>Número de Control:</label>
            <input type="text" name="numero_control" required>
            <button type="submit">Buscar</button>
        </form>

        <?php
        include '../conexion.php';

        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['numero_control'])) {
            $numero_control = $_POST['numero_control'];
            echo "<h2>Número de Control: $numero_control</h2>";

            // Consulta para obtener los módulos del alumno
            $sql = $conn->prepare("SELECT modulo, pago FROM calificaciones WHERE numero_control = ?");
            $sql->bind_param("s", $numero_control);
            $sql->execute();
            $result = $sql->get_result();

            echo "<table>
                    <tr>
                        <th>Módulo</th>
                        <th>Estado de Pago</th>
                        <th>Acción</th>
                    </tr>";

            while ($row = $result->fetch_assoc()) {
                $modulo = $row['modulo'];
                $estado_pago = $row['pago'];

                $clase_pago = ($estado_pago == 'Pagado') ? 'pagado' : 'pendiente';
                $texto_pago = ($estado_pago == 'Pagado') ? 'Pagado ✅' : 'Pendiente ❌';
                $nuevo_estado = ($estado_pago == 'Pagado') ? 'Pendiente' : 'Pagado';

                $btn_color = ($estado_pago == 'Pagado') ? '#dc3545' : '#007bff';
                $btn_texto = ($estado_pago == 'Pagado') ? 'Marcar como Pendiente' : 'Marcar como Pagado';

                echo "<tr>
                        <td>Módulo $modulo</td>
                        <td class='$clase_pago'>$texto_pago</td>
                        <td>
                            <form class='update-form' method='POST'>
                                <input type='hidden' name='numero_control' value='$numero_control'>
                                <input type='hidden' name='modulo' value='$modulo'>
                                <input type='hidden' name='nuevo_estado' value='$nuevo_estado'>
                                <button type='submit' style='background-color: $btn_color; color: white; padding: 10px; border: none; border-radius: 5px; cursor: pointer;'>
                                    $btn_texto
                                </button>
                            </form>
                        </td>
                      </tr>";
            }

            echo "</table>";
        }

        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['modulo'])) {
            $numero_control = $_POST['numero_control'];
            $modulo = $_POST['modulo'];
            $nuevo_estado = $_POST['nuevo_estado'];

            $update_sql = $conn->prepare("UPDATE calificaciones SET pago = ? WHERE numero_control = ? AND modulo = ?");
            $update_sql->bind_param("ssi", $nuevo_estado, $numero_control, $modulo);

            if ($update_sql->execute()) {
                echo "<p style='color: green; font-weight: bold;'>Estado de pago actualizado correctamente.</p>";
            } else {
                echo "<p style='color: red;'>Error al actualizar el estado.</p>";
            }
        }

        $conn->close();
        ?>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
    if (sessionStorage.getItem("scrollPosition")) {
        window.scrollTo(0, sessionStorage.getItem("scrollPosition"));
    }

    document.querySelectorAll(".update-form").forEach(function (form) {
        form.addEventListener("submit", function (event) {
            event.preventDefault();
            
            sessionStorage.setItem("scrollPosition", window.scrollY);

            let button = form.querySelector("button");
            button.disabled = true;
            fetch("", {
                method: "POST",
                body: new FormData(form)
            }).then(response => response.text())
              .then(() => location.reload())
              .catch(error => {
                  console.error("Error:", error);
                  button.disabled = false;
              });
        });
    });
});
</script>

</body>
</html>